package com.demo.spring.exception;

public class CustomerNotFoundException extends RuntimeException {

}
