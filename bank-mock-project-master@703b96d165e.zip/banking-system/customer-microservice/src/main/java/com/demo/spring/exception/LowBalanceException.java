package com.demo.spring.exception;

public class LowBalanceException extends RuntimeException {

}
