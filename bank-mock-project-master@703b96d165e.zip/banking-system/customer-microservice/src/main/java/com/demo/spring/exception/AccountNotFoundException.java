package com.demo.spring.exception;

public class AccountNotFoundException extends RuntimeException {
	
}
