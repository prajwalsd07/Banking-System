package com.demo.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontendUiApplicationTests {

	@Test
	void contextLoads() {
	}

}
